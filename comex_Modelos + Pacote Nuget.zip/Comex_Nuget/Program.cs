﻿using comex.Menus;

new MenuPrincipal().Executar();
