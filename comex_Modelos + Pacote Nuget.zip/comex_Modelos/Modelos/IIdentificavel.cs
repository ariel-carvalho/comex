﻿namespace comex.Modelos;
internal interface IIdentificavel
{
    void Identificar();
}
